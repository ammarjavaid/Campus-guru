const httpStatus = require('http-status-codes').StatusCodes;

module.exports = (req, res, next) => {
  console.log("req.user",req.user)
  const isAdmin = req.user.isAdmin;

  if (!isAdmin) {
    console.warn('Access denied. This action is reserved for admins');
    return res
      .status(httpStatus.FORBIDDEN)
      .json({ error: 'Access denied. This action is reserved for admins' });
  }

  next();
};
