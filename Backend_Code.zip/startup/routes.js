const express = require('express');
require('express-async-errors');
const user = require('../routes/user.route');
const courseProfessorRelation = require('../routes/courseProfessorRelation.route');
const courseReview = require('../routes/courseReview.route');
const course = require('../routes/course.route');
const professorReview = require('../routes/professorReview.route');
const professor = require('../routes/professor.route');
const error = require('../middlewares/error');
const userAuth = require('../routes/userAuth.route');

module.exports = (app) => {
  app.use(express.json());
  app.use('/api/auth', userAuth);
  app.use('/api/user', user);
  app.use('/api/course', course);
  app.use('/api/professor', professor);
  app.use('/api/courseProfessorRelation', courseProfessorRelation);
  app.use('/api/courseReview', courseReview);
  app.use('/api/professorReview', professorReview);
  app.use(error);
};
