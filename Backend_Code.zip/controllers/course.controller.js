const bcrypt = require('bcrypt');
const httpStatus = require('http-status-codes').StatusCodes;
const { Course, validateCourse } = require('../models/course.model');
const { Op } = require('sequelize');
const { Professor } = require('../models/professor.model');
const {
  CourseProfessorRelation,
} = require('../models/courseProfessorRelation.model');

const coursesController = {
  createCourse: async (req, res) => {
    try {
      const { error } = validateCourse(req.body);
      if (error) {
        console.warn(`Invalid data format: ${error}`);
        return res
          .status(httpStatus.BAD_REQUEST)
          .json({ error: `Invalid data format: ${error}` });
      }

      const course = await Course.findOne({
        where: {
          [Op.and]: [{ number: req.body.number }, { name: req.body.name }],
        },
      });

      if (course) {
        console.warn('course already registered');
        return res
          .status(httpStatus.CONFLICT)
          .json({ error: 'course already registered' });
      }

      const newCourse = await Course.create(req.body);
      res.status(201).json(newCourse);
    } catch (error) {
      console.error('Error creating course:', error);
      res.status(500).json({ error: 'Unable to create course' });
    }
  },

  getAllCourses: async (req, res) => {
    try {
      const courses = await Course.findAll({
        include: [
          {
            model: Professor,
            as: 'professors',
            through: {
              model: CourseProfessorRelation,
            },
          },
        ],
      });
      res.json(courses);
    } catch (error) {
      console.error('Error getting courses:', error);
      res.status(500).json({ error: 'Unable to fetch courses' });
    }
  },

  getCourse: async (req, res) => {
    const { id } = req.params;
    try {
      const course = await Course.findByPk(id, {
        include: [
          {
            model: Professor,
            as: 'professors',
            through: {
              model: CourseProfessorRelation,
            },
          },
        ],
      });
      if (!course) {
        return res.status(404).json({ error: 'Course not found' });
      }
      res.json(course);
    } catch (error) {
      console.error('Error getting course:', error);
      res.status(500).json({ error: 'Unable to fetch course' });
    }
  },

  updateCourse: async (req, res) => {
    const { id } = req.params;
    try {
      const course = await Course.findByPk(id);
      if (!course) {
        return res.status(404).json({ error: 'Course not found' });
      }

      const { error } = validateCourse(req.body);
      if (error) {
        console.warn(`Invalid data format: ${error}`);
        return res
          .status(httpStatus.BAD_REQUEST)
          .json({ error: `Invalid data format: ${error}` });
      }
      await course.update(req.body);
      res.json(course);
    } catch (error) {
      console.error('Error updating course:', error);
      res.status(500).json({ error: 'Unable to update course' });
    }
  },

  deleteCourse: async (req, res) => {
    const { id } = req.params;
    try {
      const course = await Course.findByPk(id);
      if (!course) {
        return res.status(404).json({ error: 'Course not found' });
      }

      await course.destroy();
      res.status(204).send(); // No content
    } catch (error) {
      console.error('Error deleting course:', error);
      res.status(500).json({ error: 'Unable to delete course' });
    }
  },
};

module.exports = coursesController;
