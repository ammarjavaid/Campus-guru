const bcrypt = require('bcrypt');
const httpStatus = require('http-status-codes').StatusCodes;
const {
  ProfessorReview,
  validateProfessorReview,
} = require('../models/professorReview.model');
const { Professor } = require('../models/professor.model');
const { User } = require('../models/user.model');
const { Op } = require('sequelize');

const professorReviewController = {
  createProfessorReview: async (req, res) => {
    try {
      const {
        professor_id,
        comment,
        interpersonalRelationshipsReview,
        proficiencyReview,
        teachingMethodReview,
        averageReview,
        upVotes,
        downVotes,
      } = req.body;
      const author = req.user.username;

      const [professor, user] = await Promise.all([
        Professor.findByPk(professor_id),
        User.findOne({ username: author }),
      ]);

      if (!professor || !user) {
        return res.status(404).json({ error: 'Professor or user not found' });
      }

      const newReview = await ProfessorReview.create({
        professor_id,
        author,
        comment,
        interpersonalRelationshipsReview,
        proficiencyReview,
        teachingMethodReview,
        averageReview,
        upVotes,
        downVotes,
      });

      res.status(201).json(newReview);
    } catch (error) {
      console.error('Error creating professor review:', error);
      res.status(500).json({ error: 'Unable to create professor review' });
    }
  },

  getAllProfessorReviews: async (req, res) => {
    try {
      const reviews = await ProfessorReview.findAll();
      res.json(reviews);
    } catch (error) {
      console.error('Error retrieving professor reviews:', error);
      res.status(500).json({ error: 'Unable to fetch All professor reviews' });
    }
  },

  getProfessorReview: async (req, res) => {
    const { id } = req.params;
    try {
      const reviews = await ProfessorReview.findOne({
        where: { id: id },
      });
      res.json(reviews);
    } catch (error) {
      console.error('Error retrieving professor review:', error);
      res
        .status(500)
        .json({ error: 'Unable to fetch professor review with Id: ', id });
    }
  },

  getAllProfessorReviewsForProfessor: async (req, res) => {
    const { id } = req.params;
    try {
      const reviews = await ProfessorReview.findAll({
        where: { professor_id: id },
      });
      res.json(reviews);
    } catch (error) {
      console.error('Error retrieving professor reviews:', error);
      res.status(500).json({
        error: 'Unable to fetch professor reviews for Professor Id:',
        id,
      });
    }
  },

  updateProfessorReview: async (req, res) => {
    const { id } = req.params;

    try {
      const review = await ProfessorReview.findOne({
        where: {
          [Op.and]: [{ id: id }, { author: username }],
        },
      });

      if (!review) {
        return res.status(404).json({ error: 'Review not found for user' });
      }
      await review.update(req.body);

      res.json(review);
    } catch (error) {
      console.error('Error updating professor review:', error);
      res.status(500).json({ error: error });
    }
  },

  deleteProfessorReview: async (req, res) => {
    const { id } = req.params;

    try {
      const review = await ProfessorReview.findOne({
        where: {
          [Op.and]: [{ id: id }, { author: username }],
        },
      });

      if (!review) {
        return res.status(404).json({ error: 'Review not found for user' });
      }

      await review.destroy();

      res.status(204).send();
    } catch (error) {
      console.error('Error deleting professor review:', error);
      res.status(500).json({ error: 'Unable to delete professor review' });
    }
  },
};

module.exports = professorReviewController;
