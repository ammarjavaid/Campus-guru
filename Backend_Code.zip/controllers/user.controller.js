const bcrypt = require('bcrypt');
const httpStatus = require('http-status-codes').StatusCodes;
const {
  User,
  generateUserAuthToken,
  validateUser,
} = require('../models/user.model');
const { Op } = require('sequelize');

const userController = {
  createUser: async (req, res) => {
    try {
      const { firstName, lastName, username, email, role, isActive } = req.body;
      const { error } = validateUser(req.body);
      let { password } = req.body;
      const isAdmin = false;

      if (error) {
        console.warn(`Invalid data format: ${error}`);
        return res
          .status(httpStatus.BAD_REQUEST)
          .json({ error: `Invalid data format: ${error}` });
      }
      const user = await User.findOne({
        where: {
          [Op.or]: [{ username: username }, { email: email }],
        },
      });

      if (user) {
        console.warn('User already registered');
        return res
          .status(httpStatus.CONFLICT)
          .json({ error: 'User already registered' });
      }
      const salt = await bcrypt.genSalt(10);
      password = await bcrypt.hash(password, salt);

      const newUser = await User.create({
        firstName,
        lastName,
        username,
        email,
        password,
        role,
        isAdmin,
        isActive,
      });
      const sanitizedUser = { ...newUser.get() };
      delete sanitizedUser.password;
      res.status(httpStatus.OK).json(sanitizedUser);
    } catch (error) {
      console.error('Error creating user:', error);
      res.status(500).json({ error: 'Unable to creat user' });
    }
  },

  createAdmin: async (req, res) => {
    try {
      const { firstName, lastName, username, email, role, isActive } = req.body;
      const { error } = validateUser(req.body);
      let { password } = req.body;

      const isAdmin = true;

      if (error) {
        console.warn(`Invalid data format: ${error}`);
        return res
          .status(httpStatus.BAD_REQUEST)
          .json({ error: `Invalid data format: ${error}` });
      }
      const user = await User.findOne({
        where: {
          [Op.or]: [{ username: username }, { email: email }],
        },
      });

      if (user) {
        console.warn('User already registered');
        return res
          .status(httpStatus.CONFLICT)
          .json({ error: 'User already registered' });
      }

      const salt = await bcrypt.genSalt(10);
      password = await bcrypt.hash(password, salt);

      const newUser = await User.create({
        firstName,
        lastName,
        username,
        email,
        password,
        role,
        isAdmin,
        isActive,
      });
      const sanitizedUser = { ...newUser.get() };
      delete sanitizedUser.password;
      res.status(httpStatus.OK).json(sanitizedUser);
    } catch (error) {
      console.error('Error creating user:', error);
      res.status(500).json({ error: 'Unable to creat user' });
    }
  },

  getAllUsers: async (req, res) => {
    try {
      const users = await User.findAll({
        attributes: {
          exclude: ['password'],
        },
      });

      if (!users) {
        console.warn('No Users found');
        return res
          .status(httpStatus.NOT_FOUND)
          .json({ error: 'User not found' });
      }

      res.status(httpStatus.OK).json(users);
    } catch (error) {
      console.error('Error Getting user:', error);
      res.status(500).json({ error: 'Unable to Get user' });
    }
  },

  getMyUser: async (req, res) => {
    const user = await User.findByPk(req.user.id);

    if (!user) {
      console.warn('User not found');
      return res.status(httpStatus.NOT_FOUND).json({ error: 'User not found' });
    }

    const sanitizedUser = { ...user.get() };
    delete sanitizedUser.password;

    res.status(httpStatus.OK).json(sanitizedUser);
  },

  updateUser: async (req, res) => {
    try {
      const user = await User.findByPk(req.user.id);
      if (!user) {
        console.warn('User not found');
        return res
          .status(httpStatus.NOT_FOUND)
          .json({ error: 'User not found' });
      }
      await user.update(req.body);
      const sanitizedUser = { ...user.get() };
      delete sanitizedUser.password;
      res.status(200).json(sanitizedUser);
    } catch (error) {
      console.error('Error updating user:', error);
      res.status(500).json({ error: 'Unable to update user' });
    }
  },

  deleteUser: async (req, res) => {
    try {
      const user = await User.findByPk(req.user.id);
      if (!user) {
        console.warn('User not found');
        return res
          .status(httpStatus.NOT_FOUND)
          .json({ error: 'User not found' });
      }
      await user.destroy();
      res.status(204).send(); // No content
    } catch (error) {
      console.error('Error deleting user:', error);
      res.status(500).json({ error: error });
    }
  },
};

module.exports = userController;
