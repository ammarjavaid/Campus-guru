const bcrypt = require('bcrypt');
const httpStatus = require('http-status-codes').StatusCodes;
const {
  CourseProfessorRelation,
  validateCourseProfessorRelation,
} = require('../models/courseProfessorRelation.model');
const { Course } = require('../models/course.model');
const { Professor } = require('../models/professor.model');
const { Op } = require('sequelize');

const coursesProfessorRelationController = {
  createProfessorRelation: async (req, res) => {
    try {
      const { error } = validateCourseProfessorRelation(req.body);
      if (error) {
        console.warn(`Invalid data format: ${error}`);
        return res
          .status(httpStatus.BAD_REQUEST)
          .json({ error: `Invalid data format: ${error}` });
      }

      const newRelation = await CourseProfessorRelation.create(req.body);
      res.status(201).json(newRelation);
    } catch (error) {
      console.error('Error creating course professor relation:', error);
      res
        .status(500)
        .json({ error: 'Unable to create course professor relation' });
    }
  },

  getAllProfessorRelations: async (req, res) => {
    try {
      const relations = await CourseProfessorRelation.findAll({
        include: [Course, Professor],
      });
      res.json(relations);
    } catch (error) {
      console.error('Error getting course professor relations:', error);
      res
        .status(500)
        .json({ error: 'Unable to fetch course professor relations' });
    }
  },

  getProfessorRelation: async (req, res) => {
    const { id } = req.params;
    try {
      const relation = await CourseProfessorRelation.findByPk(id, {
        include: [Course, Professor],
      });
      if (!relation) {
        return res
          .status(404)
          .json({ error: 'Course professor relation not found' });
      }
      res.json(relation);
    } catch (error) {
      console.error('Error getting course professor relation:', error);
      res
        .status(500)
        .json({ error: 'Unable to fetch course professor relation' });
    }
  },

  updateProfessorRelation: async (req, res) => {
    const { id } = req.params;
    try {
      const relation = await CourseProfessorRelation.findByPk(id);
      if (!relation) {
        return res
          .status(404)
          .json({ error: 'Course professor relation not found' });
      }

      const { error } = validateCourseProfessorRelation(req.body);
      if (error) {
        return res.status(400).json({ error: error.details[0].message });
      }

      await relation.update(req.body);
      res.json(relation);
    } catch (error) {
      console.error('Error updating course professor relation:', error);
      res
        .status(500)
        .json({ error: 'Unable to update course professor relation' });
    }
  },

  deleteProfessorRelation: async (req, res) => {
    const { id } = req.params;
    try {
      const relation = await CourseProfessorRelation.findByPk(id);
      if (!relation) {
        return res
          .status(404)
          .json({ error: 'Course professor relation not found' });
      }

      await relation.destroy();
      res.status(204).send();
    } catch (error) {
      console.error('Error deleting course professor relation:', error);
      res
        .status(500)
        .json({ error: 'Unable to delete course professor relation' });
    }
  },
};

module.exports = coursesProfessorRelationController;
