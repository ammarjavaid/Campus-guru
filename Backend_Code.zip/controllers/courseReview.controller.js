const bcrypt = require('bcrypt');
const httpStatus = require('http-status-codes').StatusCodes;
const {
  CourseReview,
  validateCourseReview,
} = require('../models/courseReview.model');
const { Course } = require('../models/course.model');
const { User } = require('../models/user.model');
const { Op } = require('sequelize');

const coursesReviewController = {
  createCourseReview: async (req, res) => {
    try {
      const {
        course_id,
        comment,
        structureReview,
        contentReview,
        difficultyReview,
        relevanceReview,
        averageReview,
      } = req.body;
      const author = req.user.username;

      const [course, user] = await Promise.all([
        Course.findByPk(course_id),
        User.findOne({ username: author }),
      ]);

      if (!course || !user) {
        return res.status(404).json({ error: 'Course or user not found' });
      }

      const newReview = await CourseReview.create({
        course_id,
        author,
        comment,
        structureReview,
        contentReview,
        difficultyReview,
        relevanceReview,
        averageReview,
      });

      res.status(201).json(newReview);
    } catch (error) {
      console.error('Error creating course review:', error);
      res.status(500).json({ error: 'Unable to create course review' });
    }
  },

  getAllCourseReviews: async (req, res) => {
    try {
      const reviews = await CourseReview.findAll();
      res.json(reviews);
    } catch (error) {
      console.error('Error getting course reviews:', error);
      res.status(500).json({ error: 'Unable to fetch course reviews' });
    }
  },

  getCourseReview: async (req, res) => {
    const { id } = req.params;
    try {
      const review = await CourseReview.findByPk(id);
      if (!review) {
        return res.status(404).json({ error: 'Course review not found' });
      }
      res.json(review);
    } catch (error) {
      console.error('Error getting course review:', error);
      res.status(500).json({ error: 'Unable to fetch course review' });
    }
  },

  getAllCourseReviewsForCourse: async (req, res) => {
    const { id } = req.params;
    try {
      const reviews = await CourseReview.findAll({
        where: { course_id: id },
      });
      res.json(reviews);
    } catch (error) {
      console.error('Error retrieving course reviews:', error);
      res.status(500).json({
        error: 'Unable to fetch course reviews for Course Id:',
        id,
      });
    }
  },

  updateCourseReview: async (req, res) => {
    const { id } = req.params;
    const username = req.user.username;
    try {
      const review = await CourseReview.findOne({
        where: {
          [Op.and]: [{ id: id }, { author: username }],
        },
      });
      if (!review) {
        return res
          .status(404)
          .json({ error: 'Course review not found for user' });
      }

      await review.update(req.body);
      res.json(review);
    } catch (error) {
      console.error('Error updating course review:', error);
      res.status(500).json({ error: error });
    }
  },

  deleteCourseReview: async (req, res) => {
    const { id } = req.params;
    const username = req.user.username;
    try {
      const review = await CourseReview.findOne({
        where: {
          [Op.and]: [{ id: id }, { author: username }],
        },
      });
      if (!review) {
        return res
          .status(404)
          .json({ error: 'Course review not found for user' });
      }

      await review.destroy();
      res.status(204).send(); // No content
    } catch (error) {
      console.error('Error deleting course review:', error);
      res.status(500).json({ error: 'Unable to delete course review' });
    }
  },
};

module.exports = coursesReviewController;
