const httpStatus = require('http-status-codes').StatusCodes;
const { Professor, validateProfessor } = require('../models/professor.model');
const { Op } = require('sequelize');
const { Course } = require('../models/course.model');
const {
  CourseProfessorRelation,
} = require('../models/courseProfessorRelation.model');

const professorController = {
  createProfessor: async (req, res) => {
    try {
      const { name, institute, faculty } = req.body;
      const { error } = validateProfessor(req.body);

      if (error) {
        console.warn(`Invalid data format: ${error}`);
        return res
          .status(httpStatus.BAD_REQUEST)
          .json({ error: `Invalid data format: ${error}` });
      }

      // const professor = await Professor.findOne({
      //     where: {
      //         [Op.and]: [{ name: name }, { institute: institute }, { faculty: faculty }],
      //     },
      // });

      // if (professor) {
      //     console.warn('Professor already registered');
      //     return res
      //         .status(httpStatus.CONFLICT)
      //         .json({ error: 'Professor already registered' });
      // }

      const newProfessor = await Professor.create(req.body);
      res.status(201).json(newProfessor);
    } catch (error) {
      console.error('Error creating professor:', error);
      res.status(500).json({ error: 'Unable to create professor' });
    }
  },

  getAllProfessors: async (req, res) => {
    try {
      const professors = await Professor.findAll({
        include: [
          {
            model: Course,
            as: 'courses',
            through: {
              model: CourseProfessorRelation,
            },
          },
        ],
      });
      res.json(professors);
    } catch (error) {
      console.error('Error getting professors:', error);
      res.status(500).json({ error: 'Unable to fetch professors' });
    }
  },

  getProfessor: async (req, res) => {
    const { id } = req.params;
    try {
      const professor = await Professor.findByPk(id, {
        include: [
          {
            model: Course,
            as: 'courses',
            through: {
              model: CourseProfessorRelation,
            },
          },
        ],
      });
      if (!professor) {
        return res.status(404).json({ error: 'Professor not found' });
      }
      res.json(professor);
    } catch (error) {
      console.error('Error getting professor:', error);
      res.status(500).json({ error: 'Unable to fetch professor' });
    }
  },

  updateProfessor: async (req, res) => {
    const { id } = req.params;
    try {
      const professor = await Professor.findByPk(id);
      if (!professor) {
        return res.status(404).json({ error: 'Professor not found' });
      }

      const { error } = validateProfessor(req.body);
      if (error) {
        console.warn(`Invalid data format: ${error}`);
        return res
          .status(httpStatus.BAD_REQUEST)
          .json({ error: `Invalid data format: ${error}` });
      }

      await professor.update(req.body);
      res.json(professor);
    } catch (error) {
      console.error('Error updating professor:', error);
      res.status(500).json({ error: 'Unable to update professor' });
    }
  },

  deleteProfessor: async (req, res) => {
    const { id } = req.params;
    try {
      const professor = await Professor.findByPk(id);
      if (!professor) {
        return res.status(404).json({ error: 'Professor not found' });
      }

      await professor.destroy();
      res.status(204).send();
    } catch (error) {
      console.error('Error deleting professor:', error);
      res.status(500).json({ error: 'Unable to delete professor' });
    }
  },
};

module.exports = professorController;
