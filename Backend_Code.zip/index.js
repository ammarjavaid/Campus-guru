const express = require('express');
const { connectToDB } = require('./startup/db');
const port = process.env.APP_PORT || 5000;
const app = express();


const cors = require('cors');

var corsOptions = {
  origin: [

    'http://localhost:3000',
    'http://localhost:3001'
  ],
};

app.use(cors(corsOptions));
require('./startup/routes')(app);

connectToDB();

app.listen(port, () => {
  console.log(`Listening on port ${port}...`);
});
