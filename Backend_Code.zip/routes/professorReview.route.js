const express = require('express');
const router = express.Router();
const professorReviews = require('../controllers/professorReview.controller');
const authenticationMiddleware = require('../middlewares/authentication');
const authorizationMiddleware = require('../middlewares/authorization');

router.get('/', professorReviews.getAllProfessorReviews);
router.get('/:id', professorReviews.getProfessorReview);
router.get(
  '/professorId/:id',
  professorReviews.getAllProfessorReviewsForProfessor
);
router.post(
  '/',
  authenticationMiddleware,
  professorReviews.createProfessorReview
);
router.patch(
  '/:id',
  authenticationMiddleware,
  professorReviews.updateProfessorReview
);
router.delete(
  '/:id',
  authenticationMiddleware,
  professorReviews.deleteProfessorReview
);

module.exports = router;
