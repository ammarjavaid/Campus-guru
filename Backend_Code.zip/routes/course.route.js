const express = require('express');
const router = express.Router();
const authenticationMiddleware = require('../middlewares/authentication');
const authorizationMiddleware = require('../middlewares/authorization');
const courses = require('../controllers/course.controller');

router.get('/', courses.getAllCourses);
router.get('/:id', courses.getCourse);
router.post(
  '/',
  [authenticationMiddleware, authorizationMiddleware],
  courses.createCourse
);
router.patch(
  '/:id',
  [authenticationMiddleware, authorizationMiddleware],
  courses.updateCourse
);
router.delete(
  '/:id',
  [authenticationMiddleware, authorizationMiddleware],
  courses.deleteCourse
);

module.exports = router;
