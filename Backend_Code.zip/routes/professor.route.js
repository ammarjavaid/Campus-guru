const express = require('express');
const router = express.Router();
const professor = require('../controllers/professor.controller');
const authenticationMiddleware = require('../middlewares/authentication');
const authorizationMiddleware = require('../middlewares/authorization');

router.get('/', professor.getAllProfessors);
router.get('/:id', professor.getProfessor);
router.post(
  '/',
  [authenticationMiddleware, authorizationMiddleware],
  professor.createProfessor
);
router.patch(
  '/:id',
  [authenticationMiddleware, authorizationMiddleware],
  professor.updateProfessor
);
router.delete(
  '/:id',
  [authenticationMiddleware, authorizationMiddleware],
  professor.deleteProfessor
);

module.exports = router;
