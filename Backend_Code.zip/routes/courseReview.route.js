const express = require('express');
const router = express.Router();
const authenticationMiddleware = require('../middlewares/authentication');
const authorizationMiddleware = require('../middlewares/authorization');
const courseReviews = require('../controllers/courseReview.controller');

router.get('/', courseReviews.getAllCourseReviews);
router.get('/:id', courseReviews.getCourseReview);
router.get('/courseId/:id', courseReviews.getAllCourseReviewsForCourse);
router.post('/', authenticationMiddleware, courseReviews.createCourseReview);
router.patch(
  '/:id',
  authenticationMiddleware,
  courseReviews.updateCourseReview
);
router.delete(
  '/:id',
  authenticationMiddleware,
  courseReviews.deleteCourseReview
);

module.exports = router;
