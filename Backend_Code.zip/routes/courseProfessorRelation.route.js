const express = require('express');
const router = express.Router();

const courseProfessorRelation = require('../controllers/courseProfessorRelation.controller');
const authenticationMiddleware = require('../middlewares/authentication');
const authorizationMiddleware = require('../middlewares/authorization');
router.get('/', courseProfessorRelation.getAllProfessorRelations);
router.get('/:id', courseProfessorRelation.getProfessorRelation);
router.post(
  '/',
  [authenticationMiddleware, authorizationMiddleware],
  courseProfessorRelation.createProfessorRelation
);
router.patch(
  '/:id',
  [authenticationMiddleware, authorizationMiddleware],
  courseProfessorRelation.updateProfessorRelation
);
router.delete(
  '/:id',
  [authenticationMiddleware, authorizationMiddleware],
  courseProfessorRelation.deleteProfessorRelation
);

module.exports = router;
