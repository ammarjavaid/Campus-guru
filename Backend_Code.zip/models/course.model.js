const { DataTypes } = require('sequelize');
const { sequelize } = require('../startup/db');
const Joi = require('joi');
const { Professor } = require('./professor.model');

const Course = sequelize.define(
  'courses',
  {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    number: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    name: {
      type: DataTypes.STRING(100),
      allowNull: false,
    },
    description: {
      type: DataTypes.STRING(500),
      defaultValue: null,
    },
    credit: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    hoursPerWeek: {
      type: DataTypes.INTEGER,
      defaultValue: null,
    },
    institute: {
      type: DataTypes.STRING(100),
      defaultValue: null,
    },
    faculty: {
      type: DataTypes.STRING(100),
      defaultValue: null,
    },
    tags: {
      type: DataTypes.STRING(100),
      defaultValue: null,
    },
    contentReview: {
      type: DataTypes.DOUBLE,
      defaultValue: null,
    },
    structureReview: {
      type: DataTypes.DOUBLE,
      defaultValue: null,
    },
    relevanceReview: {
      type: DataTypes.DOUBLE,
      defaultValue: null,
    },
    difficultyReview: {
      type: DataTypes.DOUBLE,
      defaultValue: null,
    },
    averageReview: {
      type: DataTypes.DOUBLE,
      defaultValue: null,
    },
  },
  {
    sequelize,
    modelName: 'Course',
    tableName: 'courses',
    timestamps: false,
  }
);

function validateCourse(course) {
  const courseSchema = Joi.object({
    number: Joi.number().integer().required(),
    name: Joi.string().max(100).required(),
    description: Joi.string().max(500).allow(null).default(null),
    credit: Joi.number().integer().required(),
    hoursPerWeek: Joi.number().integer().allow(null).default(null),
    institute: Joi.string().max(100).allow(null).default(null),
    faculty: Joi.string().max(100).allow(null).default(null),
    tags: Joi.string().max(100).allow(null).default(null),
    contentReview: Joi.number().allow(null).default(null),
    structureReview: Joi.number().allow(null).default(null),
    relevanceReview: Joi.number().allow(null).default(null),
    difficultyReview: Joi.number().allow(null).default(null),
    averageReview: Joi.number().allow(null).default(null),
  });
  return courseSchema.validate(course);
}

Course.belongsToMany(Professor, {
  through: 'courseprofessorrelations',
  foreignKey: 'course_id',
  otherKey: 'professor_id',
  as: 'professors',
});

Professor.belongsToMany(Course, {
  through: 'courseprofessorrelations',
  foreignKey: 'professor_id',
  otherKey: 'course_id',
  as: 'courses',
});

module.exports = { Course, validateCourse };
