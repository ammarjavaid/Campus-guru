const { DataTypes } = require('sequelize');
const { sequelize } = require('../startup/db');
const Joi = require('joi');
const { User } = require('./user.model');
const { Professor } = require('./professor.model');

const ProfessorReview = sequelize.define(
  'professorreviews',
  {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    professor_id: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    author: {
      type: DataTypes.STRING(100),
      allowNull: false,
    },
    comment: {
      type: DataTypes.STRING(500),
      defaultValue: null,
    },
    interpersonalRelationshipsReview: {
      type: DataTypes.DECIMAL(10, 0),
      defaultValue: null,
    },
    proficiencyReview: {
      type: DataTypes.DECIMAL(10, 0),
      defaultValue: null,
    },
    teachingMethodReview: {
      type: DataTypes.DECIMAL(10, 0),
      defaultValue: null,
    },
    averageReview: {
      type: DataTypes.DECIMAL(10, 0),
      defaultValue: null,
    },
    upVotes: {
      type: DataTypes.INTEGER,
      allowNull: false,
      defaultValue: 0,
    },
    downVotes: {
      type: DataTypes.INTEGER,
      allowNull: false,
      defaultValue: 0,
    },
    creationTimestamp: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: DataTypes.NOW,
    },
  },
  {
    sequelize,
    modelName: 'ProfessorReview',
    tableName: 'professorreviews',
    timestamps: false,
  }
);

function validateProfessorReview(professorReview) {
  const professorReviewSchema = Joi.object({
    professor_id: Joi.number().integer().required(),
    author: Joi.string().max(100).required(),
    comment: Joi.string().max(500).allow(null).default(null),
    interpersonalRelationshipsReview: Joi.number()
      .integer()
      .allow(null)
      .default(null),
    proficiencyReview: Joi.number().integer().allow(null).default(null),
    teachingMethodReview: Joi.number().integer().allow(null).default(null),
    averageReview: Joi.number().integer().allow(null).default(null),
    upVotes: Joi.number().integer().default(0),
    downVotes: Joi.number().integer().default(0),
    creationTimestamp: Joi.date().required(),
  });
  return professorReviewSchema.validate(professorReview);
}

ProfessorReview.belongsTo(Professor, {
  foreignKey: 'professor_id',
  targetKey: 'id',
});
ProfessorReview.belongsTo(User, {
  foreignKey: 'author',
  targetKey: 'username',
});

module.exports = { ProfessorReview, validateProfessorReview };
