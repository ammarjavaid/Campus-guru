const { DataTypes } = require('sequelize');
const { sequelize } = require('../startup/db');
const Joi = require('joi');
const { User } = require('./user.model');
const { Course } = require('./course.model');

const CourseReview = sequelize.define(
  'coursereviews',
  {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    course_id: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    author: {
      type: DataTypes.STRING(100),
      allowNull: false,
    },
    comment: {
      type: DataTypes.STRING(500),
      defaultValue: null,
    },
    structureReview: {
      type: DataTypes.DECIMAL(10, 0),
      defaultValue: null,
    },
    contentReview: {
      type: DataTypes.DECIMAL(10, 0),
      defaultValue: null,
    },
    difficultyReview: {
      type: DataTypes.DECIMAL(10, 0),
      defaultValue: null,
    },
    relevanceReview: {
      type: DataTypes.DECIMAL(10, 0),
      defaultValue: null,
    },
    averageReview: {
      type: DataTypes.DECIMAL(10, 0),
      defaultValue: null,
    },
    upVotes: {
      type: DataTypes.INTEGER,
      allowNull: false,
      defaultValue: 0,
    },
    downVotes: {
      type: DataTypes.INTEGER,
      allowNull: false,
      defaultValue: 0,
    },
    creationTimestamp: {
      type: DataTypes.DATE,
      allowNull: false,
      defaultValue: DataTypes.NOW,
    },
  },
  {
    sequelize,
    modelName: 'CourseReview',
    tableName: 'coursereviews',
    timestamps: false,
  }
);

function validateCourseReview(courseReview) {
  const courseReviewSchema = Joi.object({
    course_id: Joi.number().integer().required(),
    author: Joi.string().max(100).required(),
    comment: Joi.string().max(500).allow(null).default(null),
    structureReview: Joi.number().integer().allow(null).default(null),
    contentReview: Joi.number().integer().allow(null).default(null),
    difficultyReview: Joi.number().integer().allow(null).default(null),
    relevanceReview: Joi.number().integer().allow(null).default(null),
    averageReview: Joi.number().integer().allow(null).default(null),
    upVotes: Joi.number().integer().default(0),
    downVotes: Joi.number().integer().default(0),
    creationTimestamp: Joi.date().required(),
  });
  return courseReviewSchema.validate(courseReview);
}

CourseReview.belongsTo(Course, { foreignKey: 'course_id', targetKey: 'id' });
CourseReview.belongsTo(User, { foreignKey: 'author', targetKey: 'username' });

module.exports = { CourseReview, validateCourseReview };
