const { DataTypes } = require('sequelize');
const { sequelize } = require('../startup/db');
const Joi = require('joi');

const Professor = sequelize.define(
  'professors',
  {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
    },
    name: {
      type: DataTypes.STRING(100),
      allowNull: false,
    },
    institute: {
      type: DataTypes.STRING(100),
      defaultValue: null,
    },
    faculty: {
      type: DataTypes.STRING(100),
      defaultValue: null,
    },
    tags: {
      type: DataTypes.STRING(100),
      defaultValue: null,
    },
    interpersonalRelationshipsReview: {
      type: DataTypes.DECIMAL(10, 0),
      defaultValue: null,
    },
    professionalKnowledgeReview: {
      type: DataTypes.DECIMAL(10, 0),
      defaultValue: null,
    },
    teachingMethodReview: {
      type: DataTypes.DECIMAL(10, 0),
      defaultValue: null,
    },
    averageReview: {
      type: DataTypes.DECIMAL(10, 0),
      defaultValue: null,
    },
  },
  {
    sequelize,
    modelName: 'Professor',
    tableName: 'professors',
    timestamps: false,
  }
);

function validateProfessor(professor) {
  const professorSchema = Joi.object({
    name: Joi.string().max(100).required(),
    institute: Joi.string().max(100).allow(null).default(null),
    faculty: Joi.string().max(100).allow(null).default(null),
    tags: Joi.string().max(100).allow(null).default(null),
    interpersonalRelationshipsReview: Joi.number()
      .integer()
      .allow(null)
      .default(null),
    professionalKnowledgeReview: Joi.number()
      .integer()
      .allow(null)
      .default(null),
    teachingMethodReview: Joi.number().integer().allow(null).default(null),
    averageReview: Joi.number().integer().allow(null).default(null),
  });
  return professorSchema.validate(professor);
}

module.exports = { Professor, validateProfessor };
