const { DataTypes } = require('sequelize');
const { sequelize } = require('../startup/db');
const jwt = require('jsonwebtoken');
const Joi = require('joi');

const User = sequelize.define(
  'users',
  {
    id: {
      type: DataTypes.INTEGER,
      autoIncrement: true,
      primaryKey: true,
    },
    firstName: {
      type: DataTypes.STRING(100),
      allowNull: false,
    },
    lastName: {
      type: DataTypes.STRING(100),
      allowNull: false,
    },
    username: {
      type: DataTypes.STRING(100),
      allowNull: false,
      unique: true,
    },
    email: {
      type: DataTypes.STRING(100),
      allowNull: false,
      unique: true,
    },
    password: {
      type: DataTypes.STRING(500),
      allowNull: false,
    },
    role: {
      type: DataTypes.STRING(100),
      allowNull: false,
    },
    isAdmin: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: false,
    },
    isActive: {
      type: DataTypes.BOOLEAN,
      allowNull: false,
      defaultValue: true,
    },
  },
  {
    sequelize,
    modelName: 'User',
    tableName: 'users',
    timestamps: false,
  }
);

function generateUserAuthToken(user) {
  const token = jwt.sign(
    {
      id: user.id,
      firstName: user.firstName,
      lastName: user.lastName,
      username: user.username,
      email: user.email,
      role: user.role,
      isAdmin: user.isAdmin,
      isActive: user.isActive,
    },
    process.env.USER_JWT_PRIVATE_KEY
  );
  return token;
}

function validateUser(user) {
  const userSchema = Joi.object({
    firstName: Joi.string().max(100).required(),
    lastName: Joi.string().max(100).required(),
    username: Joi.string().max(100).required(),
    email: Joi.string().max(100).required(),
    password: Joi.string().max(500).required(),
    role: Joi.string().max(100).required(),
    isActive: Joi.boolean().required(),
  });
  return userSchema.validate(user);
}

module.exports = { User, validateUser, generateUserAuthToken };
